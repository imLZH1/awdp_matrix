#!/bin/sh
cp fix_pwn /home/ctf/pwn
